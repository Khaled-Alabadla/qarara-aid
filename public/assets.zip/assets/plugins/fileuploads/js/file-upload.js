$('.dropify').dropify({
	messages: {
		'default': 'قم باختيار ملف وإرفاقه هنا',
		'replace': 'قم باختيار ملف وإرفاقه هنا',
		'remove': 'حذف',
		'error': 'خطأ في الإرسال'
	},
	error: {
		'fileSize': 'حجم الملف كبير'
	}
});
	
