<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span>جميع الحقوق محفوظة لبلدية القرارة &copy; {{ date('Y') }}</span>
		</div>
	</div>
<!-- Footer closed -->
